//
//  ContentView.swift
//  ShoppingList
//
//  Created by Kendrix on 2024/12/08.
//

import SwiftUI

struct ContentView: View {
    @State private var itemText = ""
    @State private var shoppingList: [ShoppingItem] = []
    @State private var completedList: [ShoppingItem] = []
    @State private var recentlyDeleted: [ShoppingItem] = []
    @State private var successMessage = ""  // Success message
    @State private var errorMessage = ""    // Error message
    @State private var currentColorIndex = 0
    @State private var isAnimating = false
    @State private var isCompleted: Bool = false
    @State private var isRecentlyDeteted: Bool = false

    var body: some View {
        if isCompleted{
            VStack {
                HStack(spacing:40){
                    Text("Completed List")
                        .font(.system(size: 40))
                        .foregroundStyle(.black).bold()
                    
                    Menu{
                        Button(action: {
                            recentlyDeleted.append(contentsOf: completedList) // Add all completed items to recently deleted
                                completedList.removeAll() // Clear the completed list
                        }) {
                            Text("リストをクリア")
                                .font(.headline)
                                .foregroundColor(shoppingList.isEmpty ? Color.gray : Color.red)
                                
                        }
                       
                        Button {
                            isCompleted = false
                        } label: {
                            HStack{
                                Text("Return")
                                    .font(.headline)
                                   
                                Image(systemName: "house.fill")
                            }
                        }

                    }label: {
                        Image(systemName: "house.fill")
                            .resizable().aspectRatio(contentMode: .fill)
                            .frame(width: 30,height: 30)
                    }
                    
                }
                if completedList.isEmpty {
                    VStack{
                        Text("No completed items yet.")
                            .foregroundColor(.gray)
                            .font(.title).offset(y:-40)
                    }.frame(width: 400,height: 630)
                } else {
                    List(completedList) { item in
                        HStack {
                            Text(item.name)
                                .strikethrough()
                            Spacer()
                        }
                    }.listStyle(.plain)
                        .frame(width: 400,height: 630)
                }
            }.frame(width: 400,height: 904)
                .background(completedwallpaper())
        }else if isRecentlyDeteted{
            VStack {
                HStack(spacing:40){
                    Text("Recently Deleted")
                        .font(.system(size: 40))
                        .foregroundStyle(.black).bold()
                    Menu{
                        Button(action: {
                            recentlyDeleted.removeAll()
                        }) {
                            Text("リストをクリア")
                                .font(.headline)
                                .foregroundColor(shoppingList.isEmpty ? Color.gray : Color.red)
                        }.disabled(recentlyDeleted.isEmpty)
                       
                        
                        Button {
                            isRecentlyDeteted = false
                        } label: {
                            HStack{
                                Text("Return")
                                    .font(.headline)
                                   
                                Image(systemName: "house.fill")
                            }
                        }

                    }label: {
                        Image(systemName: "house.fill")
                            .resizable().aspectRatio(contentMode: .fill)
                            .frame(width: 30,height: 30)
                    }

                }
                if recentlyDeleted.isEmpty {
                    
                    VStack {
                       Text("No recently deleted items.")
                            .foregroundColor(.gray)
                            .font(.title).offset(y:-40)
                    }  .frame(width: 400,height: 630)
                } else {
                    List(recentlyDeleted) { item in
                        HStack {
                            Text(item.name)
                            Spacer()
                            Button(action: {
                                restoreItem(item)
                            }) {
                                Text("Restore")
                                    .foregroundColor(.blue)
                            }
                        }
                    }.listStyle(.plain)
                        .frame(width: 400,height: 630)
                }
            }//VStack
            .frame(width: 400,height: 904)
                .background(completedwallpaper())
        }
        else {
            VStack {
                HStack(spacing: 20) {
                    Text("買い物メモ")
                        .font(.system(size: 50))
                    Menu{
                        Button(action: clearList) {
                            Text("リストをクリア")
                                .padding()
                                .frame(width: 150)
                                .background(shoppingList.isEmpty ? Color.gray : Color.red)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                        .disabled(shoppingList.isEmpty)
                        
                        
                        Button(action:{
                            isCompleted = true
                        }){
                            HStack {
                                Text("Completed List")
                                    .font(.headline)
                                Image(systemName: "checkmark.seal.fill")
                                 
                            }
                        }
                        
                        Button(action:{
                            isRecentlyDeteted = true
                        }){
                            HStack {
                                Text("Recently Deleted")
                                    .font(.headline)
                                Image(systemName: "trash.fill")
                            }
                        }
                        
                    }label: {
                        Image(systemName: "gearshape.fill")
                            .resizable()
                            .frame(width: 38,height: 38)
                    }
                    
                    
                }//HStack(Title)
                .padding(.leading,70)
                
                
                ScrollView{
                    if shoppingList.isEmpty {
                        ZStack {
                            RoundedRectangle(cornerRadius: 9)
                                .fill(.white)
                                .frame(width: 350, height: 80)
                                .padding(.horizontal)
                                .shadow(radius: 5)
                            HStack {
                                Text("リストは空です")
                                    .font(.title)
                                    .foregroundColor(.gray)
                                Image(systemName: "cart")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding(.top, 5)
                    } else{
                        ForEach(shoppingList.indices, id: \.self) { index in
                            let item = shoppingList[index]
                            
                            ZStack{
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(item.backgroundColor)
                                    .frame(width: 350, height: 80)
                                    .padding(.horizontal)
                                    .shadow(radius: 5)
                                
                                HStack{
                                    Image(systemName: item.completed ? "checkmark.circle.fill" : "circle")
                                        .resizable()
                                        .frame(width: 30, height: 30)
                                        .foregroundColor(item.completed ? .green : .gray)
                                        .onTapGesture {
                                            markAsCompleted(item: item)
                                        }
                                        .padding(.leading,35)
                                    
                                    Text(item.name)
                                        .font(.title3)
                                        .foregroundColor(.black)
                                    if let sticker = item.sticker {
                                        Image(sticker)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 50, height: 50)
                                    }
                                    
                                    Spacer()
                                    
                                    Button(action: {
                                        deleteItem(item)
                                    }) {
                                        Image(systemName: "trash.fill")
                                            .resizable()
                                            .frame(width: 25, height: 30)
                                            .foregroundColor(.black)
                                           
                                            .padding(.trailing, 43)
                                    }//Button
                                    
                                }//HStack
                            }//ZStack
                            .padding(.top, 5)
                            .animation(.easeInOut(duration: 0.3), value: shoppingList)
                            
                        }//ForEach
                    }//else
                }//Scroll
                .frame(height: 550)
                VStack{
                    HStack {
                        TextField("新アイテムを入力", text: $itemText)
                            .font(.title)
                            .frame(width: 275)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        
                        Button(action: addItem) {
                            Text("追加")
                                .padding()
                                .frame(width: 80, height: 37)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                    .padding()
                    
                    // Display Success or Error Message
                    if !successMessage.isEmpty {
                        Text(successMessage)
                            .foregroundColor(.green)
                    }
                    if !errorMessage.isEmpty {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                    
                    
                }//Vstack add item row
                .offset(y:16)
                
            }.frame(width: 400,height: 904)
            .background(wallpaper())
        }//VStack
       
    }
    // Methods
    func addItem() {
        guard !itemText.isEmpty else {
            showError(message: "アイテム名を入力してください。")
            return
        }
        
        if shoppingList.contains(where: { $0.name == itemText && !$0.completed  }) {
            showError(message: "\(itemText)はすでにリストにあります。") // Show error if duplicate
        } else {
            let sticker = getSticker(for: itemText) // Get sticker based on the keyword
            let newItem = ShoppingItem(name: itemText, backgroundColor: getSoftBrightColor(), sticker: sticker, completed: false)
            shoppingList.append(newItem)
            successMessage = "\(itemText)をリストに追加しました!"
            errorMessage = "" // Clear error message if successful
            itemText = ""
        }
    }
    
    
    func deleteItem(_ item: ShoppingItem) {
        if let index = shoppingList.firstIndex(where: { $0.id == item.id }) {
            let deletedItem = shoppingList.remove(at: index)
            recentlyDeleted.append(deletedItem)
        }
    }
    
    func restoreItem(_ item: ShoppingItem) {
        if let index = recentlyDeleted.firstIndex(where: { $0.id == item.id }) {
            let restoredItem = recentlyDeleted.remove(at: index)
            shoppingList.append(restoredItem)
        }
    }
    
    func clearList() {
        shoppingList.removeAll()
    }
    
    func showError(message: String) {
        errorMessage = message // Set the error message
        successMessage = ""    // Clear any success message
        
    }
    
    func getSoftBrightColor() -> Color {
        let colors: [Color] = [
            Color(red: 168 / 255, green: 209 / 255, blue: 231 / 255),
            Color(red: 255 / 255, green: 242 / 255, blue: 123 / 255),
            Color(red: 255 / 255, green: 191 / 255, blue: 197 / 255),
            Color(red: 178 / 255, green: 250 / 255, blue: 191 / 255),
            Color(red: 235 / 255, green: 141 / 255, blue: 181 / 255),
            Color(red: 186 / 255, green: 240 / 255, blue: 240 / 255),
            Color(red: 204 / 255, green: 159 / 255, blue: 255 / 255)
        ]
        let color = colors[currentColorIndex]
        currentColorIndex = (currentColorIndex + 1) % colors.count
        return color
    }
    
    func getSticker(for text: String) -> String? {
        let keywordsToStickers: [String: String] = [
            "apple": "apple",
            "cake": "cake",
            "toast": "toast",
            "book": "book",
            "snack": "eating",
            "food": "eating",
            "meat": "meat",
            "vegetable": "vegetable",
            "drink": "cup",
            "clothes": "shopping",
            "dress": "shopping",
            "pant": "shopping",
            "outerwear": "shopping",
            "shirt": "shopping"
        ]
        
        // Convert text to lowercase for case-insensitive comparison
        let lowercasedText = text.lowercased()
        
        for (keyword, sticker) in keywordsToStickers {
            // Compare the text with the lowercase keyword
            if lowercasedText.contains(keyword.lowercased()) {
                return sticker
            }
        }
        
        return nil
    }
    
    func markAsCompleted(item: ShoppingItem) {
        if let index = shoppingList.firstIndex(where: { $0.id == item.id }) {
            var updatedItem = shoppingList[index]
            updatedItem.completed.toggle()  // Toggle the completion state
            
            // Animate the change to completed state with a delay
            withAnimation(.easeInOut(duration: 0.5)) {
                shoppingList[index] = updatedItem
            }
            
            // Move item to the completed list or back to shopping list
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                if updatedItem.completed {
                    // Move item to completed list
                    let removedItem = shoppingList.remove(at: index)
                    completedList.append(removedItem)
                } else {
                    // Move item back to shopping list if unchecked
                    shoppingList.append(updatedItem)
                    completedList.removeAll { $0.id == updatedItem.id }
                }
            }
        }
    }
}


struct ShoppingItem: Identifiable, Equatable {
    var id = UUID()
    var name: String
    var backgroundColor: Color
    var sticker: String?
    var completed: Bool = false
}

struct wallpaper:View {
    var body: some View {
        Image("wallpaper")
            .resizable()
            .scaleEffect(x:1.05,y: 1)
            
            
    }
}

struct completedwallpaper:View {
    var body: some View {
        VStack{
            Image("completed")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 400,height: 904)
              
        }
    }
}

#Preview {
    ContentView()
}

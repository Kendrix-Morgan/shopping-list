//
//  ShoppingListApp.swift
//  ShoppingList
//
//  Created by Kendrix on 2024/12/08.
//

import SwiftUI

@main
struct ShoppingListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

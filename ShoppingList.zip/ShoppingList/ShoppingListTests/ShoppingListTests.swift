//
//  ShoppingListTests.swift
//  ShoppingListTests
//
//  Created by Kendrix on 2024/12/08.
//

import Testing
@testable import ShoppingList

struct ShoppingListTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
